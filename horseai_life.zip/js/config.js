const CONFIG = {
  apiBase: 'http://localhost:3000/api' // Change to remotehost:port for production
};